#!/bin/bash

echo "Hello World" > /var/www/html/1.html
