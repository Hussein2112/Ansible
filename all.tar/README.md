companion files for my RHCE8 book
